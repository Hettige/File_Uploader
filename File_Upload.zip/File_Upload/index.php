<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>File Uploader</title>
<link rel="stylesheet" href="css1.css" >
<link rel="stylesheet" href="css2.css" >
<script src="js1.js"></script>
<style>
	body {
  padding-top: 40px;
  padding-bottom: 40px;
  background-color: #eee;
}

.form-signin {
  max-width: 330px;
  padding: 15px;
  margin:  auto;
}
.form-signin .form-signin-heading,
.form-signin .checkbox {
  margin-bottom: 10px;
}
.form-signin .checkbox {
  font-weight: normal;
}
.form-signin .form-control {
  position: relative;
  height: auto;
  -webkit-box-sizing: border-box;
     -moz-box-sizing: border-box;
          box-sizing: border-box;
  padding: 10px;
  font-size: 16px;
}
.form-signin .form-control:focus {
  z-index: 2;
}
.form-signin input[type="email"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
</style>
</head>
<body>
     <form class="form-signin" method="POST" enctype="multipart/form-data">
     	<h2 class="form-signin-heading">Upload File</h2>
	 	<div class="form-group">
	    	<label for="InputFile">File input</label>
	    	<input type="file" name="file" id="InputFile">
	  	</div>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Upload</button>
     </form>
	 <p align="center"><font face="arial">Attach any type of a file ( .doc, .pdf, .jpeg, .png, .rar, etc..)</font>
     </p>
     <br><br>
     <center>
     	<p>Click to View the uploaded files:</p><a href="view.php"><b>Open Directory</b></a>
     </center>      
<?php
require_once('connection.php');
if(isset($_FILES) & !empty($_FILES))
{
	$name = $_FILES['file']['name'];
	$size = $_FILES['file']['size'];
	$type = $_FILES['file']['type'];
	$tmp_name = $_FILES['file']['tmp_name'];
}
if(isset($name) && !empty($name))
{
		$location = "uploads/";
		if(move_uploaded_file($tmp_name, $location.$name))
		{
			$query = "INSERT INTO `upload` (name, size, type, location) VALUES ('$name', '$size', '$type', '$location$name')";
			$result = mysqli_query($connection, $query);
			
			$smsg = "Uploaded Successfully";
			
			echo '<script language="javascript">';
			echo 'alert("File upload successfully")';
			echo '</script>';
		}
		else
		{
			$fmsg = "Failed to Upload File";
			
			echo '<script language="javascript">';
			echo 'alert("File upload unsuccessfully")';
			echo '</script>';
		}
}
else
{
	$fmsg = "Please Select a File";
}
?>
<br><br><br><br><br><br><br><br><br><br>
<p align="right">Created by: M. H. Hettige</p>      
</body>
</html>