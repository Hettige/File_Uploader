<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>File Uploader</title>
<link rel="stylesheet" href="css1.css" >
<link rel="stylesheet" href="css2.css" >
<script src="js1.js"></script>
<style>
	body {
  padding-top: 40px;
  padding-bottom: 40px;
  background-color: #eee;
}

.form-signin {
  max-width: 330px;
  padding: 15px;
  margin: 0 auto;
}
.form-signin .form-signin-heading,
.form-signin .checkbox {
  margin-bottom: 10px;
}
.form-signin .checkbox {
  font-weight: normal;
}
.form-signin .form-control {
  position: relative;
  height: auto;
  -webkit-box-sizing: border-box;
     -moz-box-sizing: border-box;
          box-sizing: border-box;
  padding: 10px;
  font-size: 16px;
}
.form-signin .form-control:focus {
  z-index: 2;
}
.form-signin input[type="email"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
</style>
</head>
<body>
	<p align="right">Created by: M. H. Hettige</p>
	<center>
		<p>Go back to home page: </p><a href="index.php"><b>Home</b></a>
	</center>
	<br><br>
	<h3 align="center">Uploaded Files</h3>
	<table class="table" align="center">
	  <thead>
		<tr>
		  <th>ID</th>
		  <th>Name</th>
		  <th>Size (KB)</th>
		  <th>Type</th>
		  <th>View File</th>
		  <th>Delete</th>
		</tr>
	  </thead>
	  <tbody>
	  <?php
		require('connection.php');
		$sql = "SELECT * FROM `upload`";
		$result = mysqli_query($connection, $sql);
	  ?>
	  <?php
		while($r = mysqli_fetch_assoc($result)){
	  ?>
		<tr>
		  <th scope="row"><?php echo $r['id'] ?></th>
		  <td><?php echo $r['name'] ?></td>
		  <td><?php echo $r['size'] ?></td>
		  <td><?php echo $r['type'] ?></td>
		  <td><a href="<?php echo $r['location'] ?>"><b>View</b></a></td>
		  <form name="f1" action="delete.php" method="POST" >
			<td><a href="delete.php?id=<?php echo $r['id']?>"><b>Delete</b></a></td>
		  </form>
		</tr>
	  <?php
		}
	  ?>
	  </tbody>
	</table>
</body>
</html>