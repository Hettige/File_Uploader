<?php

require_once('connection.php');
if(isset($_GET) & !empty($_GET))
{
	$id = $_GET['id'];
	$sql = "SELECT * FROM `upload` where id=$id";
	$result = mysqli_query($connection, $sql);
	$r = mysqli_fetch_assoc($result);
	if(unlink($r['location']))
	{
		$delsql = "delete from upload where id=$id";
		if(mysqli_query($connection,$delsql))
		{
			header('location:view.php');
			
		}
	}
}
?>